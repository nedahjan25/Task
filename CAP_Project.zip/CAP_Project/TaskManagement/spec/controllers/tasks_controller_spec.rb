# spec/controllers/tasks_controller_spec.rb

require 'rails_helper'

RSpec.describe TasksController, type: :controller do
  fixtures :all  # or specify specific fixtures


  # ... other examples ...
end
