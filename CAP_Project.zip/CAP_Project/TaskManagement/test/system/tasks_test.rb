require "application_system_test_case"

class TasksTest < ApplicationSystemTestCase
  setup do
    @task = tasks(:one)
  end

  test "visiting the index" do
    visit tasks_url
    assert_selector "h1", text: "Tasks"
  end

  test "should create task" do
    visit tasks_url
    click_on "New task"

    check "Completed" if @task.completed
    fill_in "Description", with: @task.description
    fill_in "Due date", with: @task.due_date
    fill_in "Priority", with: @task.priority
    fill_in "Title", with: @task.title
    click_on "Create Task"

    assert_text "Task was successfully created"
    click_on "Back"
  end

  test "should update Task" do
    visit task_url(@task)
    click_on "Edit", match: :first

    check "Completed" if @task.completed
    fill_in "Description", with: @task.description
    fill_in "Due date", with: @task.due_date
    fill_in "Priority", with: @task.priority
    fill_in "Title", with: @task.title
    click_on "Update Task"

    save_and_open_page
    click_on "Back"
  end

  test "should destroy Task" do
    visit task_url(@task)
    click_on "Destroy this task", match: :first

    assert_text "Task was successfully destroyed"
  end
end
